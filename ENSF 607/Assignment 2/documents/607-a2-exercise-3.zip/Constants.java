package tictactoe;

public interface Constants {
	static final char SPACE_CHAR = ' ';
	static final char LETTER_O = 'O';
	static final char LETTER_X = 'X';
	static final int lowIndex = 0;
	static final int highIndex = 2;
}
